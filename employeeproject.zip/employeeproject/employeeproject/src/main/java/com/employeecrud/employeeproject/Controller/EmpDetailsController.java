package com.employeecrud.employeeproject.Controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employeecrud.employeeproject.Entity.EmpDetails;
import com.employeecrud.employeeproject.Service.EmpDetailsService;

@RestController
@RequestMapping("/api/emp")
public class EmpDetailsController {

    @Autowired
    private EmpDetailsService empDetailsService;

  
    @GetMapping("/all_emps")
    public List<EmpDetails> getAllEmployees() {
        return empDetailsService.getAllEmployees();
    }

    
    @GetMapping("/{id}")
    public ResponseEntity<EmpDetails> getEmployeeById(@PathVariable Integer id) {
        Optional<EmpDetails> employee = empDetailsService.getEmployeeById(id);
        return employee.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    
    @PostMapping("/save")
    public ResponseEntity<EmpDetails> createEmployee(@RequestBody EmpDetails empDetails) {
        EmpDetails createdEmployee = empDetailsService.createEmployee(empDetails);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdEmployee);
    }

   
    @PutMapping("/update/{id}")
    public ResponseEntity<EmpDetails> updateEmployee(@PathVariable Integer id, @RequestBody EmpDetails empDetails) {
        EmpDetails updatedEmployee = empDetailsService.updateEmployee(id, empDetails);
        return updatedEmployee != null ? ResponseEntity.ok(updatedEmployee) : ResponseEntity.notFound().build();
    }

    
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteEmployee(@PathVariable Integer id) {
        empDetailsService.deleteEmployee(id);
        return ResponseEntity.ok("Employee Deleted Successfully");
    }
}