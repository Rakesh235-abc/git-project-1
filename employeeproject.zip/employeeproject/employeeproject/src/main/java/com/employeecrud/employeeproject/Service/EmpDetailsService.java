package com.employeecrud.employeeproject.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeecrud.employeeproject.Entity.EmpDetails;
import com.employeecrud.employeeproject.Repo.EmpDetailsRepository;

@Service
public class EmpDetailsService {

	@Autowired
	private EmpDetailsRepository repository;

	public List<EmpDetails> getAllEmployees() {
		return repository.findAll();
	}

	public Optional<EmpDetails> getEmployeeById(Integer id) {
		return repository.findById(id);
	}

	public EmpDetails createEmployee(EmpDetails empDetails) {
		return repository.save(empDetails);
	}

	public EmpDetails updateEmployee(Integer id, EmpDetails empDetails) {
		if (repository.existsById(id)) {
			empDetails.setId(id);
			return repository.save(empDetails);
		}
		return null;
	}

	public void deleteEmployee(Integer id) {
		repository.deleteById(id);
	}

}