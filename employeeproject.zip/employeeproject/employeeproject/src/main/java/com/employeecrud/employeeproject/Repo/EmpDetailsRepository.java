package com.employeecrud.employeeproject.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.employeecrud.employeeproject.Entity.EmpDetails;

@Repository
public interface EmpDetailsRepository extends JpaRepository<EmpDetails,Integer>{
	
}